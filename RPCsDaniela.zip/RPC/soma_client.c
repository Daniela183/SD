#include "soma.h"

float adicao(CLIENT * clnt, float valor1, float valor2){
	valores num;
	float *result;
	
	num.valor1=valor1;
	num.valor2=valor2;
	result = adicao_100(&num, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);
	}
	return *result;
}//fim da função
float subtracao(CLIENT * clnt, float valor1, float valor2){
	valores num;
	float *result;
	
	num.valor1=valor1;
	num.valor2=valor2;
	result = subtracao_100(&num, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);
	}
	return *result;
}//fim da função
float multiplicacao(CLIENT * clnt, float valor1, float valor2){
	valores num;
	float *result;
	
	num.valor1=valor1;
	num.valor2=valor2;
	result = multiplicacao_100(&num, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);
	}
	return *result;
}//fim da função
float divisao(CLIENT * clnt, float valor1, float valor2){
	valores num;
	float *result;
	
	num.valor1=valor1;
	num.valor2=valor2;
	result = divisao_100(&num, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);
	}
	return *result;
}//fim da função
//função main

float main(int argc, char *argv[]){
	CLIENT* clnt;
	float valor1, valor2;
	
	printf("Informe o valor1: ");
	scanf("%f",&valor1);
	printf("Informe o valor2: ");
	scanf("%f",&valor2);
	
	clnt = clnt_create (argv[1], SOMA, VERSAO, "udp");
	if (clnt == (CLIENT *)NULL) {
		clnt_pcreateerror (argv[1]);
		exit (0);
	}
	
	printf("O servidor retornou como resultado: \n");
	printf("%.2f\n", adicao(clnt, valor1, valor2));
	return (0);
}

