#include "soma.h"

float *
adicao_100_svc(valores *argp, struct svc_req *rqstp)
{
	static float  result;

	//printf("\n");
	//printf("Desenvolvido por Maik Elamide versão3.0\n");
	//printf("\n");
	printf("Serviço RPC(servidor)\n");
	printf("\n");
	printf("O cliente solicita: \n");
	printf("Operação de adição para %.2f e %.2f\n", argp->valor1, argp-> valor2);
	result = argp-> valor1 + argp-> valor2;
	printf("Resultado da adição: %.2f\n\n", result);
	return &result;
}
float*

subtracao_100_svc (cal "argp, struct svc_req * rqstp) {

static float result;

	//printf("-------------------------------------------\n");
	//printf("Desenvolvido por Maik Elamide de versao 3.0\n");
	//printf("-------------------------------------------\n");
	printf("           Serviço RCP (Servidor)          \n");
	printf("\n");
	printf("          O cliente solicita:              \n");
	printf("Operacao de subtração para %.2f e %.2f\n", argp->valor1, argp->valor2);
	result = argp->valor1 - argp->valor1;
	printf("Resultado da subtração: %.2f\n\n",result);
	return & result;
}//fim da função

float*

multiplicacao_100_svc (cal "argp, struct svc_req * rqstp) {

static float result;

	//printf("-------------------------------------------\n");
	//printf("Desenvolvido por Maik Elamide de versao 3.0\n");
	//printf("-------------------------------------------\n");
	printf("           Serviço RCP (Servidor)          \n");
	printf("\n");
	printf("         O cliente solicita:               \n");
	printf("Operacao de multiplicação para %.2f e %.2f\n", argp->valor1, argp->valor2);
	result = argp->valor1 * argp->valor1;
	printf("Resultado da multiplicação: %.2f\n\n",result);
	return & result;
}//fim da função

float*

divisao_100_svc (cal "argp, struct svc_req * rqstp) {

static float result;

	//printf("-------------------------------------------\n");
	//printf("Desenvolvido por Maik Elamide de versao 3.0\n");
	//printf("-------------------------------------------\n");
	printf("           Serviço RCP (Servidor)          \n");
	printf("\n");
	printf("          O cliente solicita:               \n");
	printf("Operação de divisão para %.2f e %.2f\n", argp->valor1, argp->valor2);
	result = argp->valor1 / argp->valor1;
	printf("Resultado da divisão: %.2f\n\n",result);
	return & result;
}//fim da função

