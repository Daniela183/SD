#include "rpc.h"
#include <stdio.h>

float adicao(CLIENT * clnt, float valor1, float valor2){
	operacoes opr;
	float *result;
	
	opr.valor1=valor1;
	opr.valor2=valor2;
	result = adicao_100(&opr, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);}
	return *result;
	
}
float subtracao(CLIENT * clnt, float valor1, float valor2){
	operacoes opr;
	float *result;
	
	opr.valor1=valor1;
	opr.valor2=valor2;
	result = subtracao_100(&opr, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);}
	return *result;
	
}
float multiplicacao(CLIENT * clnt, float valor1, float valor2){
	operacoes opr;
	float *result;
	
	opr.valor1=valor1;
	opr.valor2=valor2;
	result = multiplicacao_100(&opr, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);}
	return *result;
	
}
float divisao(CLIENT * clnt, float valor1, float valor2){
	operacoes opr;
	float *result;
	
	opr.valor1=valor1;
	opr.valor2=valor2;
	result = divisao_100(&opr, clnt);
	
	if(result == NULL){
		fprintf(stderr, "Houve um problema na chamada do RPC\n");
		exit(0);}
	return *result;
}

float main(int argc, char *argv[]){
	CLIENT* clnt;
	float valor1, valor2;
	
	printf("-------------------------------------------\n");
	printf("Desenvolvido por Maik Elamide de versao 3.0\n");
	printf("-------------------------------------------\n");
	printf("           Service RC (Servlidor)          \n");
	printf("-------------------------------------------\n");
	printf("Escolha uma operação:                      \n");
	printf("1 - Adição                               \n");
	printf("2 - Subtração                            \n");
	printf("3 - Multiplicação                        \n");
	printf("4 - Divisão                              \n");
	printf("-------------------------------------------\n");
	scanf("%d", &operacoes);
	printf("-------------------------------------------\n");
	printf("Informe o primeiro valor: ");
	scanf("%f", &valor1);
	printf("Informe o segundo valor: ");
	scanf("%f", &valor2);
	printf("-------------------------------------------\n");

	
	clnt = clnt_create (argv[1], SOMA, VERSAO, "udp");
	if (clnt == (CLIENT *)NULL) {
		clnt_pcreateerror (argv[1]);
		exit (0);}
	
	switch (operacoes) {
	case 1:
		printf("O servidor encontrou o seguinte resultado: \n");
		printf("%.2f + %.2f = %.2f\n", valor1, valor2, adicao(clnt, valor1, valor2));
		break;

	case 2:
		printf("O servidor encontrou o seguinte resultado: \n");
		printf("%.2f - %.2f = %.2f\n", valor1, valor2, subtracao(clnt, valor1, valor2));
		break;

	case 3:
		printf("O servidor encontrou o seguinte resultado: \n");
		printf("%.2f * %.2f = %.2f\n", valor1, valor2, multiplicacao(clnt, valor1, valor2));
		break;

	case 4:
		if (valor2 != 0) {
		printf("O servidor encontrou o seguinte resultado: \n");
		printf("%.2f / %.2f = %.2f\n", valor1, valor2, divisao(clnt, valor1, valor2));
		}else {
		printf("Não existe divisão por 0!\n");}
		break;

	default:
		printf("Operação inválida!"\n);
		printf("Escolha um tipo de operador: 1 para [+], 2 para [-], 3 para [*], 4 para [/]");
	}
	return (0);
}	
	
