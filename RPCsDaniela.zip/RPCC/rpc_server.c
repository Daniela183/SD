#include "rpc.h"

float * adicao_100_svc(operacoes *argp, struct svc_req *rqstp){
	static float  result;

	printf("\n");
	printf("Desenvolvido por Maik Elamide versão3.0\n");
	printf("\n");
	printf("Serviço RPC(servidor)\n");
	printf("\n");
	printf("O cliente solicita: \n");
	printf("Operação de adição para %.2f e %.2f\n", argp->valor1, argp-> valor2);
	result = argp-> valor1 + argp-> valor2;
	printf("Resultado da adição: %.2f\n\n", result);
	return &result;
}

float * subtracao_100_svc(operacoes *argp, struct svc_req *rqstp){
	static float  result;

	printf("\n");
	printf("Desenvolvido por Maik Elamide versão3.0\n");
	printf("\n");
	printf("Serviço RPC(servidor)\n");
	printf("\n");
	printf("O cliente solicita: \n");
	printf("Operação de subtracao para %.2f e %.2f\n", argp->valor1, argp-> valor2);
	result = argp-> valor1 - argp-> valor2;
	printf("Resultado da subtracao: %.2f\n\n", result);
	return &result;
}

float * multiplicacao_100_svc(operacoes *argp, struct svc_req *rqstp){
	static float  result;

	printf("\n");
	printf("Desenvolvido por Maik Elamide versão3.0\n");
	printf("\n");
	printf("Serviço RPC(servidor)\n");
	printf("\n");
	printf("O cliente solicita: \n");
	printf("Operação de multiplicacao para %.2f e %.2f\n", argp->valor1, argp-> valor2);
	result = argp-> valor1 * argp-> valor2;
	printf("Resultado da multiplicacao: %.2f\n\n", result);
	return &result;
}

float * divisao_100_svc(operacoes *argp, struct svc_req *rqstp){
	static float  result;

	printf("\n");
	printf("Desenvolvido por Maik Elamide versão3.0\n");
	printf("\n");
	printf("Serviço RPC(servidor)\n");
	printf("\n");
	printf("O cliente solicita: \n");
	printf("Operação de divisao para %.2f e %.2f\n", argp->valor1, argp-> valor2);
	result = argp-> valor1 / argp-> valor2;
	printf("Resultado da divisao: %.2f\n\n", result);
	return &result;
}
